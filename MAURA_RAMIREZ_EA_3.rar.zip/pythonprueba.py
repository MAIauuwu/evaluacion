nuevaOpcion = -1
lista_De_Run = [  ]
gananciasTotales = 0


asientos = [
    [1,2,3,4,5,6,7,8,9,10],
    [11,12,13,14,15,16,17,18,19,20],
    [21,22,23,24,25,26,27,28,29,30],
    [31,32,33,34,35,36,37,38,39,40],
    [41,42,43,44,45,46,47,48,49,50]
]

while nuevaOpcion != 0:
        nuevaOpcion = -1
        print("----- Bienvenido al portal para comprar entradas del concierto -----\nMichael Jackson - Sanchez Producciones")
        print("Ingrese a cuál menú de la operación que desea llevar:")
        print("1. Comprar entradas.")
        print("2. Mostrar ubicaciones disponibles.")
        print("3. Mostrar lista de asistentes")
        print("4. Mostrar ganancias totales")
        print("5. Salir")
        eleccionMenu = int(input())
        match eleccionMenu:
            case 1:
                print("Ha ingresado a la opción de comprar entradas: ")
                cantidadDeEntradas = int(input("¿Comprará 1 o 2 entradas? "))
                for compra in range(cantidadDeEntradas):       
                            for imprimir in asientos:
                                print(imprimir)
                            selección = int(input("Indique cuál asiento desea comprar: "))
                            if 1<=selección<21:
                                asientos[0][selección-11] = "x"
                                gananciasTotales = gananciasTotales + 100000
                            if 21 <= selección < 31:
                                asientos[2][selección-21] = "x"
                                gananciasTotales = gananciasTotales + 500000
                            if 31<= selección < 51:
                                asientos[3][selección-41] = "x"
                                gananciasTotales = gananciasTotales + 10000
                            run = int(input("Ingrese su rut "))
                            lista_De_Run.append(run)
                            print("Se ha realizado de forma correcta su compra")
            case 2:
                print("Ha ingresado a asientos disponibles")
                for imprimir2 in asientos:
                    print(imprimir2)
            case 3:
                print("Ha ingresado a la opción de asistentes que han ingresado")
                for impresion in lista_De_Run:
                    print(impresion)
            case 4:
                print("Ha ingresado a la opción de ver ganancias obtenidas")
                print("Se ha recaudado un total de ", gananciasTotales, " pesos")
            case 5:
                from datetime import date
                print("Ha seleccionado salir\n Maura Ramirez")
                print(date)
                break